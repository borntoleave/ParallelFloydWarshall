void tic() ;
void toc() ;
double etime( ) ;