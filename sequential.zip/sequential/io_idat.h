/*--------------------------------------------------*/
/* FILE:  io_dat.h                                  */
/*--------------------------------------------------*/

void read_idat( char * fname, int * mp, int * np, int *& zzp )  ;

void write_idat( int m, int n, int * zp, char * fname )  ;
